import http.server
import socketserver
import json
import os

PORT = 8081
ARQUIVO_DADOS = "dados/inventario.txt"

class GeoHandler(http.server.SimpleHTTPRequestHandler):
    def do_POST(self):
        if self.path == '/salvar':
            length = int(self.headers['Content-Length'])
            body = self.rfile.read(length).decode('utf-8')
            dados = json.loads(body)

            usuario = dados.get('usuario', 'Anônimo')
            linha = f"Usuário: {usuario} | Data: {dados.get('data')} | Espécie: {dados.get('especie')} | Altura: {dados.get('altura')}m | GPS: {dados.get('coordenadas')} | Protegida: {dados.get('protegida')}\n"
            
            os.makedirs("dados", exist_ok=True)
            with open(ARQUIVO_DADOS, "a", encoding="utf-8") as f:
                f.write(linha)

            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            response = {"status": "sucesso", "mensagem": "Registro salvo no servidor!"}
            self.wfile.write(json.dumps(response).encode('utf-8'))
        else:
            self.send_error(404)

print("==========================================")
print(f"  🌿 SERVIDOR GEOÁRVORE INICIADO!")
print(f"  Acesse no navegador: http://localhost:{PORT}")
print("==========================================")

with socketserver.TCPServer(("", PORT), GeoHandler) as httpd:
    httpd.serve_forever()

