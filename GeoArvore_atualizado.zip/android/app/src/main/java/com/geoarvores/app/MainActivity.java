package com.geoarvores.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
